"""Runtime smoke-test assets."""
